# LeRobot支持的模仿学习算法

https://github\.com/huggingface/lerobot/tree/main/src/lerobot/policies

![image\.png](图片和附件/image.png)



