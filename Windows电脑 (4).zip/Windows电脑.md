# Windows电脑

打开`设备管理器`，先插上`从动臂`，再插上`主动臂`，查看对应的COM口编号

![image\.png](图片和附件/image.png)

## 记录我的端口号

从动臂：

COM6

主动臂：

COM7

