# 训练命令行\-WALL\-OSS（国产开源之光）

## 参考文档

https://github\.com/huggingface/lerobot/blob/46e19ae579f80ce66211afafd1c3c649c569131f/docs/source/walloss\.mdx

## 安装环境

```Shell
cd lerobot
pip install -e ".[feetech,wallx]"
```

## 训练命令行

```Shell
python lerobot/src/lerobot/scripts/lerobot_train.py \
    --dataset.repo_id=TommyZihao/lerobot_zihao_dataset_shake_hands \
    --dataset.root=~/lerobot_zihao_dataset_shake_hands \
    --policy.type=wall_x \
    --output_dir=~/output_lerobot_train/shake/wallx_A \
    --job_name=shake_wallx_a \
    --policy.pretrained_name_or_path=x-square-robot/wall-oss-flow \
    --policy.prediction_mode=diffusion \
    --policy.attn_implementation=eager \
    --policy.push_to_hub=false \
    --wandb.enable=true \
    --wandb.project=Lerobot_Zihao_Project \
    --steps=30000 \
    --policy.device=cuda \
    --batch_size=8
```

模型压缩包大约7\.2G

## 自变量机器人全球具身智能黑客松

![1a16cf8d6581b804983ce42dce43b492\.png](图片和附件/1a16cf8d6581b804983ce42dce43b492.png)



