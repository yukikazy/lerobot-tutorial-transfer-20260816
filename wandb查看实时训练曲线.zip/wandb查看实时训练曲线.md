# wandb查看实时训练曲线

- 获取wandb链接

类似：https://wandb\.ai/tommyzihao/Lerobot\_Zihao\_Project/runs/q5ylvvko

![image\.png](图片和附件/image%201.png)

- 查看训练实时曲线

![image\.png](图片和附件/image.png)



