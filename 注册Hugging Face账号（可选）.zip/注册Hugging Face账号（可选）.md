# 注册Hugging Face账号（可选）

## 设置HuggingFace国内镜像

- Ubuntu

```Shell
sudo nano ~/.bashrc

# 在文件末尾加入
export HF_ENDPOINT=https://hf-mirror.com
```

```Shell
source ~/.bashrc
echo $HF_ENDPOINT

# 输出
# https://hf-mirror.com
```

- Mac

```Shell
sudo nano ~/.zshrc

# 在文件末尾加入
export HF_ENDPOINT=https://hf-mirror.com
```

```Shell
source ~/.zshrc

# 输出
# https://hf-mirror.com
```



## 创建Token

https://huggingface\.co/settings/tokens

![image\.png](图片和附件/image%206.png)

![image\.png](图片和附件/image%201.png)

![image\.png](图片和附件/image.png)

## 记录Token

例如，我的是：

```Shell
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
```

## 绑定Token

```Shell
hf auth login

hf auth whoami
```

![image\.png](图片和附件/image%202.png)

## 创建Dataset Repo

![image\.png](图片和附件/image%204.png)

![image\.png](图片和附件/image%203.png)

![image\.png](图片和附件/image%205.png)









