# Windows电脑



## 校准从动臂Follower

```Shell
lerobot-calibrate --robot.type=so101_follower --robot.port=COM6 --robot.id=zihao_follower_arm
```

![image\.png](图片和附件/image%201.png)

## 校准主动臂Leader

```Shell
lerobot-calibrate --teleop.type=so101_leader --teleop.port=COM7 --teleop.id=zihao_leader_arm
```

![image\.png](图片和附件/image.png)

## 文件导出位置

C:\\Users\\40743\\\.cache\\huggingface\\lerobot\\calibration\\robots\\so101\_follower\\zihao\_follower\_arm\.json

C:\\Users\\40743\\\.cache\\huggingface\\lerobot\\calibration\\teleoperators\\so101\_leader\\zihao\_leader\_arm\.json





## 换机械臂

lerobot\-calibrate \-\-robot\.type=so101\_follower \-\-robot\.port=COM4 \-\-robot\.id=zihao\_follower\_arm

