# 上传数据集到HuggingFace（可选）

# 方法一：本地上传（不推荐，上传网速慢）

- 自动上传

在采集数据集时设置`push_to_hub=true`，采集完毕后自动上传

![image\.png](图片和附件/image%203.png)

- 手动上传

在采集数据集时设置`push_to_hub=false`，采集完毕后手动上传

```Shell
hf upload TommyZihao/lerobot_zihao_dataset_a /Users/tommy/.cache/huggingface/lerobot/TommyZihao/lerobot_zihao_dataset_a / --repo-type=dataset
```



无论自动上传还是手动上传，上传速度都很慢（每秒钟一百KB）

因为HuggingFace服务器在国外

# 方法二：云GPU平台上传（推荐）

## 登录云GPU平台Featurize

https://featurize\.cn?s=d7ce99f842414bfcaea5662a97581bd1

跟客服说是同济子豪兄粉丝，领取代金券

## 开启一个云GPU实例

## 上传数据集压缩包到`数据集`

## 复制实例下载命令

![image\.png](图片和附件/image%202.png)

## 在云GPU实例的命令行中运行

```Shell
pip install httpx

unzip lerobot_zihao_dataset_a.zip

hf auth login
```

## 上传数据集到HuggingFace

创建`upload_dataset.py`文件，内容如下

```Python
from huggingface_hub import HfApi

api = HfApi()

api.upload_folder(
    folder_path="~/lerobot_zihao_dataset_a",
    repo_id="TommyZihao/lerobot_zihao_dataset_a",
    repo_type="dataset"
)

api.create_tag("TommyZihao/lerobot_zihao_dataset_a", tag="v0.4.0", repo_type="dataset")
```

运行文件

```Shell
python upload_dataset.py
```

![image\.png](图片和附件/image%201.png)

- 另一种上传方法（不推荐）

```Shell
hf upload TommyZihao/lerobot_zihao_dataset_a lerobot_zihao_dataset_a / --repo-type=dataset
```

![image\.png](图片和附件/image%205.png)

# 查看HuggingFace上的数据集

https://huggingface\.co/datasets/TommyZihao/lerobot\_zihao\_dataset\_a

![image\.png](图片和附件/image%204.png)

![image\.png](图片和附件/image.png)



