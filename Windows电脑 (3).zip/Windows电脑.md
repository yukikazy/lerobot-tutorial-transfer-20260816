# Windows电脑

## 安装Miniconda

anaconda\.com/download/success

或者直接点这个链接下载安装包

https://repo\.anaconda\.com/miniconda/Miniconda3\-latest\-Windows\-x86\_64\.exe

![image\.png](图片和附件/image%201.png)

![image\.png](图片和附件/image%205.png)

## conda换源

```Shell
# 先清空原有源配置（避免冲突）
conda config --remove-key channels

# 将 conda 的默认源和常用第三方源替换为清华镜像
# 添加默认包源（main/r/msys2）
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/main/
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/r/
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/msys2/

# 添加常用第三方源
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/conda-forge/
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/msys2/
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/bioconda/
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/menpo/
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/pytorch/

# 开启显示下载源，安装包时会显示具体的下载地址
conda config --set show_channel_urls yes

# 清除索引缓存，使新源生效
conda clean -i

# 查看当前配置（验证源是否添加成功）
conda config --show-sources
```

## 创建虚拟环境

```Shell
conda create -y -n lerobot python=3.10
```

## 激活虚拟环境

```Shell
conda activate lerobot
```

## 安装ffmpeg

```Shell
conda install *ffmpeg*=7.1.1 *-c* conda-forge -y
```

验证安装成功

```Shell
ffmpeg
```

![image\.png](图片和附件/image%206.png)

![image\.png](图片和附件/image%203.png)

![image\.png](图片和附件/image%204.png)

## 下载矽递科技维护的lerobot代码仓库

https://github\.com/Seeed\-Projects/lerobot

下载压缩包，解压

## 安装代码仓库

```Shell
cd lerobot

pip install -e ".[feetech]"
```

![image\.png](图片和附件/image.png)

## 验证安装成功

```Shell
python

import lerobot
import scservo_sdk
import torch
torch.cuda.is_available()
```

![image\.png](图片和附件/image%202.png)



