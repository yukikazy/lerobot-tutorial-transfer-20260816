# 上传模型到HuggingFace（可选）

## 创建模型Repo

![image\.png](图片和附件/image.png)

![image\.png](图片和附件/image%201.png)

## 查看模型Repo

https://huggingface\.co/TommyZihao/lerobot\_zihao\_model\_a

现在是空的

![image\.png](图片和附件/image%203.png)

![image\.png](图片和附件/image%204.png)

## 上传模型

创建`upload_model.py`文件，内容如下

```Python
from huggingface_hub import HfApi

api = HfApi()

repo_id = "TommyZihao/lerobot_zihao_model_shake_hands"

api.upload_folder(
    folder_path="~/output_lerobot_train/b/checkpoints/last/pretrained_model",
    repo_id=repo_id,
    repo_type="model"
)

api.create_tag(repo_id, tag="v0.1.0", repo_type="model")
```

运行

```Shell
python upload_model.py
```

![be7686a3cbc9caffe00ffcba6b82b2e7\.png](图片和附件/be7686a3cbc9caffe00ffcba6b82b2e7.png)

## 查看模型Repo

https://huggingface\.co/TommyZihao/lerobot\_zihao\_model\_a

![image\.png](图片和附件/image%202.png)

现在有了模型文件



