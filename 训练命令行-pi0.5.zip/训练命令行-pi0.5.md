# 训练命令行\-pi0\.5

## 参考文档

https://github\.com/huggingface/lerobot/blob/46e19ae579f80ce66211afafd1c3c649c569131f/docs/source/pi0\.mdx

https://www\.pi\.website/blog/pi05

## 推荐云GPU实例

![image\.png](图片和附件/image.png)

## 安装环境

```Shell
cd lerobot
pip install -e ".[pi0]"
```

## 命令行

- 删除之前训练中断的output下的文件

```Shell
sudo rm -rf output_lerobot_train/shake/pi05_A
```

- 训练

```Shell
lerobot-train \
    --dataset.repo_id=TommyZihao/lerobot_zihao_dataset_shake_hands \
    --dataset.root=~/lerobot_zihao_dataset_shake_hands \
    --dataset.revision=v0.1.0 \
    --policy.type=pi05 \
    --output_dir=~/output_lerobot_train/shake/pi05_A \
    --job_name=shake_pi05_A \
    --policy.pretrained_path=lerobot/pi05_base \
    --policy.compile_model=true \
    --policy.gradient_checkpointing=true \
    --policy.dtype=bfloat16 \
    --policy.freeze_vision_encoder=false \
    --policy.train_expert_only=false \
    --steps=50000 \
    --policy.device=cuda \
    --policy.push_to_hub=false \
    --wandb.enable=true \
    --wandb.project=Lerobot_Zihao_Project \
    --batch_size=8
```

![image\.png](图片和附件/image%201.png)

![image\.png](图片和附件/image%202.png)

命令行运行20分钟后，训练才会正式开始

模型压缩包5个G左右，解压后7个G

